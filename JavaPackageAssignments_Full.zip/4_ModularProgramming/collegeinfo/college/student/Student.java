package college.student;
public class Student {
    public void showStudent() {
        System.out.println("Student from collegeinfo module");
    }
}