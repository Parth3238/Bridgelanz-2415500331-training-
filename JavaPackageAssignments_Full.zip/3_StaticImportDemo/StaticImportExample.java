import static java.lang.Math.*;
public class StaticImportExample {
    public static void main(String[] args) {
        System.out.println("Sqrt of 16: " + sqrt(16));
        System.out.println("Pow(2,3): " + pow(2,3));
        System.out.println("Max(10,20): " + max(10,20));
        System.out.println("Min(10,20): " + min(10,20));
        System.out.println("Abs(-10): " + abs(-10));
    }
}