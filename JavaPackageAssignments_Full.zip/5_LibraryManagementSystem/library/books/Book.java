package library.books;
public class Book {
    public void addBook(String title) {
        System.out.println("Book Added: " + title);
    }
}