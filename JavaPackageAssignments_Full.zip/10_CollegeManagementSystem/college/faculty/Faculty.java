package college.faculty;
public class Faculty {
    public void display() {
        System.out.println("Faculty: Dr. Singh");
    }
}