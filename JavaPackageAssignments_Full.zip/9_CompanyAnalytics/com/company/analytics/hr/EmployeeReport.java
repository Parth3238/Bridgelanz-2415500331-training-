package com.company.analytics.hr;
public class EmployeeReport {
    public void printEmployeePerformance() {
        System.out.println("Employee performance report generated.");
    }
}