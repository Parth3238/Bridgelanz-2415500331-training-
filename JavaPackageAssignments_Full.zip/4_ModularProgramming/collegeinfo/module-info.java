module collegeinfo {
    exports college.student;
}