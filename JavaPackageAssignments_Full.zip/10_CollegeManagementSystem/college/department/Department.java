package college.department;
public class Department {
    public void display() {
        System.out.println("Department: Computer Science");
    }
}