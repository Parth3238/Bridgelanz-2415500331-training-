package library.members;
public class Member {
    public void registerMember(String name) {
        System.out.println("Member Registered: " + name);
    }
}