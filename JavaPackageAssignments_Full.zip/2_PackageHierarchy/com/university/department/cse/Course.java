package com.university.department.cse;
public class Course {
    public void showCourse() {
        System.out.println("Course: B.Tech CSE");
    }
}