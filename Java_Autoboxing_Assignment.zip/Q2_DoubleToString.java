public class Q2_DoubleToString {
    public static void main(String[] args) {
        double num = 25.67;
        String str = Double.toString(num);
        System.out.println(str);
    }
}
