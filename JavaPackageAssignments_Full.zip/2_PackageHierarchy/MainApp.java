import com.university.department.cse.Course;
public class MainApp {
    public static void main(String[] args) {
        Course c = new Course();
        c.showCourse();
    }
}