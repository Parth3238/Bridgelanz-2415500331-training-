import com.access.two.Derived;
public class AccessTest {
    public static void main(String[] args) {
        Derived d = new Derived();
        d.showAccess();
    }
}