package Marker_Interfaces.Sensitive_Data_Tagging;

public interface ISensitiveData { }

