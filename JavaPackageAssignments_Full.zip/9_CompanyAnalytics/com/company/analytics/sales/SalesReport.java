package com.company.analytics.sales;
public class SalesReport {
    public void printSales() {
        System.out.println("Region-wise sales report generated.");
    }
}