package Functional_Interface.Digital_Payment_Interface;

public interface IPayment {
    void pay(double amount);
}
