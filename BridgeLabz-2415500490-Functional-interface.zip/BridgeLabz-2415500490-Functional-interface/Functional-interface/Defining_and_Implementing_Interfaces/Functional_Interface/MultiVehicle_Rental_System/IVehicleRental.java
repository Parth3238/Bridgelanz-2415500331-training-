package Functional_Interface.MultiVehicle_Rental_System;

public interface IVehicleRental {
    void rent();
    void returnVehicle();
   
}
