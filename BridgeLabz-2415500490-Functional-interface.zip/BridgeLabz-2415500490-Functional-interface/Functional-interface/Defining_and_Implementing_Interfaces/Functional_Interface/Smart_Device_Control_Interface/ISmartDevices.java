package Functional_Interface.Smart_Device_Control_Interface;

public interface ISmartDevices {
    void turnOn();
    void turnOff();
}
