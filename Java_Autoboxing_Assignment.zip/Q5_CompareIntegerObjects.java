public class Q5_CompareIntegerObjects {
    public static void main(String[] args) {
        Integer a = 100, b = 100;
        Integer x = 200, y = 200;
        System.out.println(a == b);
        System.out.println(x == y);
        System.out.println(a.equals(b));
        System.out.println(x.equals(y));
    }
}
