package Functional_Interface.Smart_Device_Control_Interface;

public class AcImpl implements ISmartDevices {
    @Override
    public void turnOn() {
        System.out.println("AC is turned ON");
    }
    
    @Override
    public void turnOff() {
        System.out.println("AC is turned OFF");
    }

}
