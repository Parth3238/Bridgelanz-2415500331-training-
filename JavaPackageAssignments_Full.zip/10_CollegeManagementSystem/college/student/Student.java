package college.student;
public class Student {
    public void display() {
        System.out.println("Student: Rahul");
    }
}